# ESP32 Passive 802.11 Sniffer (ESP-IDF 5.1)

Sniffer thụ động dùng ESP32, xem gói tin thời gian thực qua trình duyệt
điện thoại (WebSocket), điều khiển bằng lệnh gõ kiểu bot Telegram.

## Giới hạn phạm vi (quan trọng)

Project này **chỉ nhận (sniff) gói tin**. Toàn bộ mã nguồn không có bất kỳ
lời gọi `esp_wifi_80211_tx()` nào — đây là API duy nhất trên ESP32 dùng để
phát/giả mạo bất kỳ frame 802.11 nào (bao gồm deauth). Bạn có thể tự xác
minh bằng lệnh:

```bash
grep -rn "esp_wifi_80211_tx" main/
```

Kết quả phải rỗng. Mục "deauth" trong bảng lọc (`filter_names.h`) chỉ dùng
để **phân loại/hiển thị** khi ESP32 nghe được gói deauth ai đó phát ra
trong không khí xung quanh (hữu ích để phát hiện tấn công lên mạng của
bạn) — không phải để tạo ra gói đó.

## Yêu cầu

- ESP-IDF **5.1** đã cài đặt và `. export.sh` (hoặc `export.bat` trên Windows)
- Board ESP32 bất kỳ (không cần SD card, không cần OTG)
- Điện thoại/máy tính có trình duyệt hỗ trợ WebSocket (Chrome, Firefox...)

## Cấu trúc project

```
esp32-sniffer/
├── CMakeLists.txt              # project gốc
├── sdkconfig.defaults          # cấu hình mặc định (buffer Wi-Fi, httpd...)
└── main/
    ├── CMakeLists.txt          # đăng ký source + embed index.html vào firmware
    ├── Kconfig.projbuild       # menuconfig: SSID/pass AP, kênh mặc định
    ├── sniffer_main.c          # lõi sniffer — nhận gói, KHÔNG có hàm gửi
    ├── sniffer.h               # interface dùng chung
    ├── frame_types.h           # struct pcap + enum nhóm frame
    ├── filter_names.h          # bảng tên lệnh /filter -> bitmask
    ├── web_server.c            # httpd + websocket + parser lệnh
    ├── web_server.h
    └── index.html              # giao diện web (embed thẳng vào firmware)
```

## Build & Flash

```bash
cd esp32-sniffer
idf.py set-target esp32          # hoặc esp32s3, esp32c3... tuỳ board bạn có
idf.py menuconfig                # (tuỳ chọn) đổi SSID/pass AP, kênh mặc định
                                  # tại menu "ESP32 Sniffer Configuration"
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor    # đổi cổng theo máy bạn (COM3 trên Windows)
```

Sau khi flash, log Serial sẽ hiện dòng:
```
I (xxx) sniffer_core: Sniffer started on channel 6
I (xxx) web_server: Web server + WebSocket san sang tai '/' va '/ws'
```

## Sử dụng

1. Trên điện thoại: vào Wi-Fi, kết nối mạng **ESP32-Sniffer**
   (mật khẩu mặc định `sniffer123`, đổi được qua `idf.py menuconfig`).
2. Mở trình duyệt, truy cập `http://192.168.4.1/`
3. Trang sẽ tự kết nối WebSocket và bắt đầu hiện gói tin thời gian thực.
4. Gõ lệnh vào ô cuối trang, kiểu bot Telegram:

| Lệnh | Tác dụng |
|---|---|
| `/help` | Hiện danh sách lệnh |
| `/start` | Bắt đầu sniff (bật promiscuous mode) |
| `/stop` | Dừng sniff (tắt promiscuous mode, web vẫn truy cập được) |
| `/scan TenWifiNhaBan` | Quét toàn bộ kênh, tìm đúng SSID này, tự khoá sniffer sang đúng kênh AP đó đang phát |
| `/filter beacon probe deauth` | Chỉ hiện các loại gói liệt kê (cách nhau bằng dấu cách) |
| `/filter mgmt` | Hiện cả nhóm Management (gộp tất cả subtype mgmt) |
| `/filter all` | Hiện lại tất cả gói |
| `/pause` | Tạm dừng hiển thị (sniffer vẫn chạy ngầm, vẫn đếm thống kê) |
| `/resume` | Tiếp tục hiển thị tất cả |
| `/clear` | Xoá bảng hiển thị + reset bộ đếm |
| `/stats` | Xem thống kê tổng số gói theo nhóm + kênh hiện tại |
| `/channel 6` | Đổi sang kênh Wi-Fi số 6 (1-13) |
| `/hop 300` | Bật tự động đổi kênh mỗi 300ms (đặt `0` để tắt) |
| `/subtypes` | Liệt kê chi tiết TỪNG loại gói (Beacon, Deauth, RTS...) và số lượng đã thực sự bắt được |

### Tên loại gói dùng được trong `/filter`

**Management:** `assocreq` `assocresp` `reassocreq` `reassocresp`
`probereq` `proberesp` `beacon` `atim` `disassoc` `auth` `deauth` `action`

**Control:** `blockackreq` `blockack` `pspoll` `rts` `cts` `ack` `cfend`

**Data:** `data` `nulldata` `qosdata` `qosnull`

**Nhóm gộp:** `mgmt` `ctrl` `data` `all`

Ví dụ: `/filter beacon proberesp qosdata` — chỉ hiện Beacon, Probe Response,
và QoS Data, ẩn mọi loại khác (thống kê tổng vẫn đếm đủ, chỉ hiển thị bị lọc).

## Scan & tự động khoá kênh theo SSID

Thay vì đoán mò hoặc dùng channel hopping chung chung, bạn có thể yêu cầu
ESP32 quét chính xác kênh của 1 mạng cụ thể:

```
/scan TenWifiNhaBan
```

Cơ chế: dùng `esp_wifi_scan_start()` — API quét Wi-Fi tiêu chuẩn (giống
điện thoại "dò mạng"), đọc trực tiếp trường kênh (`primary`) trong kết quả
quét của AP có SSID khớp, rồi gọi `sniffer_set_channel()` để khoá đúng kênh
đó. Đây là cách **chính xác nhất** vì lấy thẳng thông tin kênh AP tự công bố
qua beacon, không phải suy đoán qua đo lưu lượng.

Lưu ý:
- Quá trình quét mất khoảng 1-2 giây (quét tuần tự cả 13 kênh), trong lúc
  đó sniffer tạm ngưng rồi tự bật lại ngay sau khi quét xong.
- Nếu không tìm thấy SSID (mạng ẩn, ngoài tầm sóng, hoặc gõ sai tên), server
  trả về thông báo không tìm thấy — kênh hiện tại giữ nguyên, không đổi.
- Sau khi khoá kênh qua `/scan`, `/hop` vẫn hoạt động bình thường nếu bạn
  muốn tắt khoá và quay lại chế độ quét nhiều kênh.

## Giao diện web (cập nhật mới)

- **Nút Start/Stop**: sniffer KHÔNG tự chạy khi cắm điện nữa — ESP32 khởi
  động Wi-Fi AP + web server sẵn sàng, nhưng bạn phải bấm **▶ Start** trên
  trang web (hoặc gõ `/start`) để bắt đầu nhận gói.
- **Xem chi tiết 1 gói**: bấm vào bất kỳ dòng nào trong bảng "Trực tiếp"
  để mở hộp thoại hiện đầy đủ: Frame Control, 3 địa chỉ MAC, cờ To/From DS,
  Retry, Protected, và **hex dump** toàn bộ nội dung frame.
- **Tải file .pcap**: nút **⬇ Tải .pcap** gom toàn bộ gói đã nhận được
  (lưu tạm trong RAM trình duyệt dưới dạng mảng byte) thành 1 file `.pcap`
  chuẩn, tải thẳng về điện thoại — ESP32 không lưu gì cả, ngắt kết nối là
  mất nếu chưa tải. Mở file này trong Wireshark hoặc app đọc pcap trên
  Android để phân tích sâu hơn.
- **Tab "Loại gói bắt được"**: bảng liệt kê chính xác những loại gói
  (Beacon, ProbeReq, Deauth, RTS, QoSData...) mà sniffer đã THỰC SỰ bắt
  được và số lượng mỗi loại — tự làm mới mỗi 3 giây khi đang mở tab này,
  giúp bạn biết môi trường xung quanh có gì mà không cần đoán.

## Ghi chú kỹ thuật

- Không dùng SD card — dữ liệu chỉ tồn tại đủ lâu để đóng gói và đẩy ngay
  qua WebSocket (`s_out_buf` static, không giữ lịch sử).
- Callback `wifi_sniffer_cb` chạy trong context Wi-Fi driver ưu tiên cao
  nên không `malloc()`/log nhiều trong đó, tránh làm rớt gói hoặc treo hệ thống.
- EAPOL (bắt tay WPA) hiện đang được gộp trong `data`/`qosdata` vì nó là
  Data frame có LLC/SNAP đặc biệt trong payload, không phải subtype riêng
  của Frame Control. Có thể mở rộng thêm parser LLC nếu cần lọc riêng EAPOL.
- Board không có PSRAM: nếu thấy log `Wifi Buffer full` khi lưu lượng cao,
  có thể giảm `CONFIG_ESP_WIFI_DYNAMIC_RX_BUFFER_NUM` trong `sdkconfig.defaults`
  hoặc bật channel hopping chậm hơn để giảm tải xử lý.
