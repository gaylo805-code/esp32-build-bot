/*
 * frame_types.h
 * ------------------------------------------------------------
 * Định nghĩa cấu trúc dùng để PHÂN LOẠI và ĐÓNG GÓI các gói
 * 802.11 bắt được ở chế độ promiscuous.
 *
 * File này CHỈ chứa struct và bảng tra cứu tên loại/subtype để
 * hiển thị. KHÔNG có bất kỳ hàm dựng frame để gửi (không có
 * esp_wifi_80211_tx ở bất cứ đâu trong project này).
 * ------------------------------------------------------------
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- Nhóm frame chính (2 bit trong Frame Control) ----
typedef enum {
    FRAME_GROUP_MGMT = 0,
    FRAME_GROUP_CTRL = 1,
    FRAME_GROUP_DATA = 2,
    FRAME_GROUP_RESERVED = 3
} frame_group_t;

// ---- pcap global header (ghi 1 lần khi client mới kết nối, để
//      trình xem phía web biết định dạng dữ liệu) ----
typedef struct __attribute__((packed)) {
    uint32_t magic_number;   // 0xa1b2c3d4
    uint16_t version_major;  // 2
    uint16_t version_minor;  // 4
    int32_t  thiszone;       // 0
    uint32_t sigfigs;        // 0
    uint32_t snaplen;        // 2346 (max 802.11 frame ESP32 trả về)
    uint32_t network;        // 105 = LINKTYPE_IEEE802_11
} pcap_global_hdr_t;

// ---- pcap record header (đi trước mỗi gói) ----
typedef struct __attribute__((packed)) {
    uint32_t ts_sec;
    uint32_t ts_usec;
    uint32_t incl_len;
    uint32_t orig_len;
} pcap_rec_hdr_t;

static inline void frame_types_fill_global_header(pcap_global_hdr_t *hdr)
{
    hdr->magic_number  = 0xa1b2c3d4;
    hdr->version_major = 2;
    hdr->version_minor = 4;
    hdr->thiszone      = 0;
    hdr->sigfigs       = 0;
    hdr->snaplen       = 2346;
    hdr->network       = 105; // LINKTYPE_IEEE802_11
}

// Trả về tên nhóm frame dạng chuỗi ngắn, dùng cho log / lệnh /stats
static inline const char *frame_group_name(frame_group_t g)
{
    switch (g) {
        case FRAME_GROUP_MGMT: return "mgmt";
        case FRAME_GROUP_CTRL: return "ctrl";
        case FRAME_GROUP_DATA: return "data";
        default: return "rsvd";
    }
}

#ifdef __cplusplus
}
#endif
