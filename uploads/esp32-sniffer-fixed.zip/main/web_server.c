/*
 * web_server.c
 * ------------------------------------------------------------
 * HTTP + WebSocket server (dùng esp_http_server có sẵn trong
 * ESP-IDF 5.1) để:
 *   1. Phục vụ trang HTML xem gói tin thời gian thực (embed sẵn
 *      trong firmware qua EMBED_FILES, không cần SD card).
 *   2. Nhận lệnh dạng "/lenh tham_so" từ client qua WebSocket,
 *      kiểu bot Telegram, để điều khiển bộ lọc/kênh/hopping.
 *   3. Đẩy từng gói (đã đóng gói dạng pcap record) ra tất cả
 *      client đang mở kết nối, ngay khi sniffer bắt được.
 * ------------------------------------------------------------
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "esp_http_server.h"
#include "esp_log.h"
#include "sniffer.h"
#include "filter_names.h"
#include "web_server.h"

static const char *TAG = "web_server";

// index_html.h được sinh tự động lúc build từ index.html qua EMBED_FILES
extern const uint8_t index_html_start[] asm("_binary_index_html_start");
extern const uint8_t index_html_end[]   asm("_binary_index_html_end");

static httpd_handle_t s_server = NULL;

// Danh sách fd của các websocket client đang mở, để broadcast gói tin.
#define MAX_WS_CLIENTS 4
static int s_ws_fds[MAX_WS_CLIENTS];
static int s_ws_fd_count = 0;

static void ws_client_add(int fd)
{
    for (int i = 0; i < s_ws_fd_count; i++) {
        if (s_ws_fds[i] == fd) return;
    }
    if (s_ws_fd_count < MAX_WS_CLIENTS) {
        s_ws_fds[s_ws_fd_count++] = fd;
        ESP_LOGI(TAG, "WS client connected, fd=%d (total=%d)", fd, s_ws_fd_count);
    }
}

static void ws_client_remove(int fd)
{
    for (int i = 0; i < s_ws_fd_count; i++) {
        if (s_ws_fds[i] == fd) {
            s_ws_fds[i] = s_ws_fds[s_ws_fd_count - 1];
            s_ws_fd_count--;
            ESP_LOGI(TAG, "WS client disconnected, fd=%d (total=%d)", fd, s_ws_fd_count);
            return;
        }
    }
}

// ------------------------------------------------------------
// Được sniffer_main.c gọi mỗi khi có gói mới (đã lọc theo mask).
// Đẩy dữ liệu nhị phân ra tất cả websocket client đang mở.
// ------------------------------------------------------------
static void on_packet_ready(const uint8_t *data, size_t len)
{
    if (s_ws_fd_count == 0 || !s_server) return;

    httpd_ws_frame_t frame = {
        .final = true,
        .fragmented = false,
        .type = HTTPD_WS_TYPE_BINARY,
        .payload = (uint8_t *)data,
        .len = len,
    };

    for (int i = 0; i < s_ws_fd_count; i++) {
        esp_err_t err = httpd_ws_send_frame_async(s_server, s_ws_fds[i], &frame);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "Gui goi toi fd=%d that bai (%s), se go client nay", s_ws_fds[i], esp_err_to_name(err));
            ws_client_remove(s_ws_fds[i]);
            i--; // danh sách đã dồn lại sau remove, xét lại vị trí i
        }
    }
}

// ------------------------------------------------------------
// Gửi 1 chuỗi text (JSON nhỏ) trả lời cho lệnh, chỉ tới fd gọi lệnh.
// ------------------------------------------------------------
static void ws_reply_text(httpd_handle_t hd, int fd, const char *msg)
{
    httpd_ws_frame_t frame = {
        .final = true,
        .fragmented = false,
        .type = HTTPD_WS_TYPE_TEXT,
        .payload = (uint8_t *)msg,
        .len = strlen(msg),
    };
    httpd_ws_send_frame_async(hd, fd, &frame);
}

// ------------------------------------------------------------
// Parser lệnh kiểu bot Telegram: "/ten_lenh tham_so1 tham_so2 ..."
// Đây là nơi DUY NHẤT diễn giải văn bản gõ từ client — không có
// đường nào từ đây dẫn tới việc dựng/gửi frame 802.11.
// ------------------------------------------------------------
static void handle_command(httpd_handle_t hd, int fd, char *cmd_line)
{
    char reply[256];

    // tách lệnh và phần tham số
    char *cmd = strtok(cmd_line, " \t");
    if (!cmd) return;

    if (strcasecmp(cmd, "/help") == 0) {
        snprintf(reply, sizeof(reply),
            "{\"type\":\"info\",\"msg\":"
            "\"Lenh: /start | /stop | /scan <ssid> | /filter <ten...> | "
            "/filter all | /pause | /resume | /clear | /stats | /subtypes | "
            "/channel <1-13> | /hop <ms|0> | /help\"}");
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/filter") == 0) {
        uint64_t mask = 0;
        char *tok;
        int matched = 0, unknown = 0;
        char unknown_list[128] = {0};

        while ((tok = strtok(NULL, " \t")) != NULL) {
            uint64_t bit = filter_mask_for_name(tok);
            if (bit == 0) {
                unknown++;
                strncat(unknown_list, tok, sizeof(unknown_list) - strlen(unknown_list) - 2);
                strncat(unknown_list, " ", sizeof(unknown_list) - strlen(unknown_list) - 1);
            } else {
                mask |= bit;
                matched++;
            }
        }

        if (matched > 0) {
            sniffer_set_filter_mask(mask);
        }

        snprintf(reply, sizeof(reply),
            "{\"type\":\"info\",\"msg\":\"Da ap dung filter: %d loai khop%s%s\"}",
            matched,
            unknown > 0 ? ", khong nhan dien: " : "",
            unknown > 0 ? unknown_list : "");
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/pause") == 0) {
        sniffer_set_filter_mask(0);
        ws_reply_text(hd, fd, "{\"type\":\"info\",\"msg\":\"Da tam dung hien thi (sniffer van chay ngam)\"}");
        return;
    }

    if (strcasecmp(cmd, "/resume") == 0) {
        sniffer_set_filter_mask(0xFFFFFFFFFFFFFFFFULL);
        ws_reply_text(hd, fd, "{\"type\":\"info\",\"msg\":\"Da tiep tuc hien thi tat ca goi\"}");
        return;
    }

    if (strcasecmp(cmd, "/clear") == 0) {
        sniffer_reset_stats();
        ws_reply_text(hd, fd, "{\"type\":\"clear\"}");
        return;
    }

    if (strcasecmp(cmd, "/stats") == 0) {
        sniffer_stats_t st;
        sniffer_get_stats(&st);
        snprintf(reply, sizeof(reply),
            "{\"type\":\"stats\",\"total\":%lu,\"mgmt\":%lu,\"ctrl\":%lu,\"data\":%lu,\"channel\":%d,\"running\":%s}",
            (unsigned long)st.total, (unsigned long)st.mgmt,
            (unsigned long)st.ctrl, (unsigned long)st.data,
            sniffer_get_channel(), sniffer_is_running() ? "true" : "false");
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/channel") == 0) {
        char *arg = strtok(NULL, " \t");
        if (!arg) {
            snprintf(reply, sizeof(reply), "{\"type\":\"info\",\"msg\":\"Kenh hien tai: %d\"}", sniffer_get_channel());
        } else {
            int ch = atoi(arg);
            if (sniffer_set_channel((uint8_t)ch) == ESP_OK) {
                snprintf(reply, sizeof(reply), "{\"type\":\"info\",\"msg\":\"Da doi sang kenh %d\"}", ch);
            } else {
                snprintf(reply, sizeof(reply), "{\"type\":\"info\",\"msg\":\"Kenh khong hop le (1-13)\"}");
            }
        }
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/hop") == 0) {
        char *arg = strtok(NULL, " \t");
        uint32_t interval = arg ? (uint32_t)atoi(arg) : 0;
        sniffer_set_hop_interval(interval);
        snprintf(reply, sizeof(reply),
            interval > 0 ? "{\"type\":\"info\",\"msg\":\"Bat hopping moi %lu ms\"}"
                         : "{\"type\":\"info\",\"msg\":\"Da tat hopping\"}",
            (unsigned long)interval);
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/start") == 0) {
        esp_err_t err = sniffer_start();
        if (err == ESP_OK) {
            snprintf(reply, sizeof(reply),
                "{\"type\":\"run_state\",\"running\":true,\"msg\":\"Sniffer da bat dau tren kenh %d\"}",
                (int)sniffer_get_channel());
        } else {
            snprintf(reply, sizeof(reply),
                "{\"type\":\"info\",\"msg\":\"Loi khi start: %s\"}", esp_err_to_name(err));
        }
        ws_reply_text(hd, fd, reply);
        return;
    }

    if (strcasecmp(cmd, "/stop") == 0) {
        sniffer_stop();
        ws_reply_text(hd, fd, "{\"type\":\"run_state\",\"running\":false,\"msg\":\"Sniffer da dung\"}");
        return;
    }

    if (strcasecmp(cmd, "/subtypes") == 0) {
        uint32_t counts[SNIFFER_SUBTYPE_SLOTS];
        sniffer_get_subtype_counts(counts);

        // Dựng JSON: chỉ liệt kê những subtype có tên trong FILTER_TABLE
        // và có count > 0, để bảng gọn, đúng những gì THỰC SỰ bắt được.
        char buf[768];
        int pos = snprintf(buf, sizeof(buf), "{\"type\":\"subtypes\",\"items\":[");
        bool first = true;
        for (size_t i = 0; i < FILTER_TABLE_LEN; i++) {
            int shift = (FILTER_TABLE[i].group == FRAME_GROUP_MGMT) ? 0 :
                        (FILTER_TABLE[i].group == FRAME_GROUP_CTRL) ? 16 : 32;
            int slot = shift + FILTER_TABLE[i].subtype;
            if (slot < 0 || slot >= SNIFFER_SUBTYPE_SLOTS) continue;
            uint32_t c = counts[slot];
            if (c == 0) continue; // chỉ hiện loại đã thực sự bắt được ít nhất 1 gói

            pos += snprintf(buf + pos, sizeof(buf) - pos,
                "%s{\"name\":\"%s\",\"group\":\"%s\",\"count\":%lu}",
                first ? "" : ",", FILTER_TABLE[i].name,
                frame_group_name(FILTER_TABLE[i].group), (unsigned long)c);
            first = false;
            if (pos >= (int)sizeof(buf) - 64) break; // an toàn tránh tràn buffer
        }
        snprintf(buf + pos, sizeof(buf) - pos, "]}");
        ws_reply_text(hd, fd, buf);
        return;
    }

    if (strcasecmp(cmd, "/scan") == 0) {
        char *ssid = strtok(NULL, ""); // lấy nguyên phần còn lại làm SSID (có thể có khoảng trắng)
        if (!ssid || strlen(ssid) == 0) {
            ws_reply_text(hd, fd, "{\"type\":\"info\",\"msg\":\"Dung: /scan <ten_ssid>\"}");
            return;
        }

        ws_reply_text(hd, fd, "{\"type\":\"info\",\"msg\":\"Dang quet, cho 1-2 giay...\"}");

        sniffer_scan_result_t result;
        esp_err_t err = sniffer_scan_and_lock(ssid, &result);

        if (err != ESP_OK) {
            snprintf(reply, sizeof(reply), "{\"type\":\"info\",\"msg\":\"Scan loi: %s\"}", esp_err_to_name(err));
        } else if (result.found) {
            snprintf(reply, sizeof(reply),
                "{\"type\":\"scan_result\",\"found\":true,\"ssid\":\"%s\",\"channel\":%d,"
                "\"rssi\":%d,\"bssid\":\"%02x:%02x:%02x:%02x:%02x:%02x\"}",
                result.ssid, result.channel, result.rssi,
                result.bssid[0], result.bssid[1], result.bssid[2],
                result.bssid[3], result.bssid[4], result.bssid[5]);
        } else {
            snprintf(reply, sizeof(reply),
                "{\"type\":\"scan_result\",\"found\":false,\"msg\":\"Khong thay SSID '%s'\"}", ssid);
        }
        ws_reply_text(hd, fd, reply);
        return;
    }

    snprintf(reply, sizeof(reply), "{\"type\":\"info\",\"msg\":\"Lenh khong xac dinh. Go /help de xem danh sach.\"}");
    ws_reply_text(hd, fd, reply);
}

// ------------------------------------------------------------
// HTTP GET "/" -> trả về trang HTML embed sẵn trong firmware
// ------------------------------------------------------------
static esp_err_t root_get_handler(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html");
    size_t len = index_html_end - index_html_start;
    return httpd_resp_send(req, (const char *)index_html_start, len);
}

// ------------------------------------------------------------
// WebSocket handler tại "/ws" — nhận text frame chứa lệnh, hoặc
// xử lý sự kiện handshake để đăng ký fd vào danh sách broadcast.
// ------------------------------------------------------------
static esp_err_t ws_handler(httpd_req_t *req)
{
    if (req->method == HTTP_GET) {
        // Handshake xong -> đăng ký fd để nhận broadcast gói tin
        int fd = httpd_req_to_sockfd(req);
        ws_client_add(fd);
        char msg[96];
        snprintf(msg, sizeof(msg), "{\"type\":\"run_state\",\"running\":%s}",
                 sniffer_is_running() ? "true" : "false");
        ws_reply_text(req->handle, fd, msg);
        return ESP_OK;
    }

    httpd_ws_frame_t ws_pkt;
    memset(&ws_pkt, 0, sizeof(ws_pkt));
    ws_pkt.type = HTTPD_WS_TYPE_TEXT;

    esp_err_t ret = httpd_ws_recv_frame(req, &ws_pkt, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "httpd_ws_recv_frame failed to get len: %s", esp_err_to_name(ret));
        return ret;
    }

    if (ws_pkt.len == 0) {
        return ESP_OK; // ping hoặc frame rỗng
    }

    uint8_t *buf = calloc(1, ws_pkt.len + 1);
    if (!buf) return ESP_ERR_NO_MEM;
    ws_pkt.payload = buf;

    ret = httpd_ws_recv_frame(req, &ws_pkt, ws_pkt.len);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "httpd_ws_recv_frame failed: %s", esp_err_to_name(ret));
        free(buf);
        return ret;
    }

    if (ws_pkt.type == HTTPD_WS_TYPE_TEXT) {
        int fd = httpd_req_to_sockfd(req);
        if (buf[0] == '/') {
            handle_command(req->handle, fd, (char *)buf);
        }
    }

    free(buf);
    return ESP_OK;
}

esp_err_t web_server_start(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.max_open_sockets = MAX_WS_CLIENTS + 1;
    config.stack_size = 8192;

    esp_err_t err = httpd_start(&s_server, &config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "httpd_start that bai: %s", esp_err_to_name(err));
        return err;
    }

    httpd_uri_t root_uri = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = root_get_handler,
    };
    httpd_register_uri_handler(s_server, &root_uri);

    httpd_uri_t ws_uri = {
        .uri = "/ws",
        .method = HTTP_GET,
        .handler = ws_handler,
        .is_websocket = true,
    };
    httpd_register_uri_handler(s_server, &ws_uri);

    sniffer_register_output_cb(on_packet_ready);

    ESP_LOGI(TAG, "Web server + WebSocket san sang tai '/' va '/ws'");
    return ESP_OK;
}
