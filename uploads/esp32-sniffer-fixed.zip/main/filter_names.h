/*
 * filter_names.h
 * ------------------------------------------------------------
 * Ánh xạ tên gõ trong lệnh /filter (kiểu bot Telegram) sang
 * (group, subtype) tương ứng trong chuẩn 802.11, để dựng bitmask
 * truyền cho sniffer_set_filter_mask().
 *
 * Đây thuần là bảng tra cứu tên hiển thị/lọc — không có logic
 * dựng hay gửi frame nào ở đây.
 * ------------------------------------------------------------
 */
#pragma once

#include <stdint.h>
#include <string.h>
#include <strings.h>
#include "frame_types.h"

typedef struct {
    const char *name;
    frame_group_t group;
    uint8_t subtype;
} filter_entry_t;

// Subtype theo chuẩn 802.11 (giá trị 4 bit trong Frame Control).
// Mgmt subtypes:
//   0000 AssocReq   0001 AssocResp   0010 ReassocReq  0011 ReassocResp
//   0100 ProbeReq   0101 ProbeResp   1000 Beacon      1001 ATIM
//   1010 Disassoc   1011 Auth        1100 Deauth      1101 Action
// Ctrl subtypes (rút gọn các loại phổ biến):
//   1001 RTS  1010 CTS  1011 ACK  1000 BlockAckReq  1001... (BlockAck=1000? xem bảng chuẩn)
// Data subtypes:
//   0000 Data   0100 Null(no data)   1000 QoS Data   1100 QoS Null
static const filter_entry_t FILTER_TABLE[] = {
    // ---- Management ----
    { "assocreq",    FRAME_GROUP_MGMT, 0x0 },
    { "assocresp",   FRAME_GROUP_MGMT, 0x1 },
    { "reassocreq",  FRAME_GROUP_MGMT, 0x2 },
    { "reassocresp", FRAME_GROUP_MGMT, 0x3 },
    { "probereq",    FRAME_GROUP_MGMT, 0x4 },
    { "proberesp",   FRAME_GROUP_MGMT, 0x5 },
    { "beacon",      FRAME_GROUP_MGMT, 0x8 },
    { "atim",        FRAME_GROUP_MGMT, 0x9 },
    { "disassoc",    FRAME_GROUP_MGMT, 0xA },
    { "auth",        FRAME_GROUP_MGMT, 0xB },
    { "deauth",      FRAME_GROUP_MGMT, 0xC }, // chỉ NHẬN diện gói này nếu nó xuất hiện trong không khí
    { "action",      FRAME_GROUP_MGMT, 0xD },

    // ---- Control ----
    { "blockackreq", FRAME_GROUP_CTRL, 0x8 },
    { "blockack",    FRAME_GROUP_CTRL, 0x9 },
    { "pspoll",      FRAME_GROUP_CTRL, 0xA },
    { "rts",         FRAME_GROUP_CTRL, 0xB },
    { "cts",         FRAME_GROUP_CTRL, 0xC },
    { "ack",         FRAME_GROUP_CTRL, 0xD },
    { "cfend",       FRAME_GROUP_CTRL, 0xE },

    // ---- Data ----
    { "data",        FRAME_GROUP_DATA, 0x0 },
    { "nulldata",    FRAME_GROUP_DATA, 0x4 },
    { "qosdata",     FRAME_GROUP_DATA, 0x8 },
    { "qosnull",     FRAME_GROUP_DATA, 0xC },
    // EAPOL không phải 1 subtype riêng (nó là Data frame với LLC/SNAP đặc
    // biệt trong payload) — ở mức lọc đơn giản này ta gộp nó vào "data"/
    // "qosdata"; lọc sâu hơn theo LLC type có thể thêm sau nếu cần.
};

#define FILTER_TABLE_LEN (sizeof(FILTER_TABLE) / sizeof(FILTER_TABLE[0]))

// Nhóm gộp lớn: mgmt/ctrl/data (dùng khi gõ /filter mgmt)
static inline int filter_name_is_group(const char *name, frame_group_t *out_group)
{
    if (strcasecmp(name, "mgmt") == 0)  { *out_group = FRAME_GROUP_MGMT; return 1; }
    if (strcasecmp(name, "ctrl") == 0)  { *out_group = FRAME_GROUP_CTRL; return 1; }
    if (strcasecmp(name, "data") == 0)  { *out_group = FRAME_GROUP_DATA; return 1; }
    return 0;
}

static inline uint64_t filter_mask_for_group(frame_group_t g)
{
    uint64_t mask = 0;
    for (size_t i = 0; i < FILTER_TABLE_LEN; i++) {
        if (FILTER_TABLE[i].group == g) {
            int shift = (g == FRAME_GROUP_MGMT) ? 0 : (g == FRAME_GROUP_CTRL) ? 16 : 32;
            mask |= (1ULL << (shift + FILTER_TABLE[i].subtype));
        }
    }
    return mask;
}

// Trả về bit tương ứng 1 tên cụ thể (beacon, deauth, rts...), 0 nếu không tìm thấy.
static inline uint64_t filter_mask_for_name(const char *name)
{
    frame_group_t g;
    if (filter_name_is_group(name, &g)) {
        return filter_mask_for_group(g);
    }
    for (size_t i = 0; i < FILTER_TABLE_LEN; i++) {
        if (strcasecmp(FILTER_TABLE[i].name, name) == 0) {
            int shift = (FILTER_TABLE[i].group == FRAME_GROUP_MGMT) ? 0 :
                        (FILTER_TABLE[i].group == FRAME_GROUP_CTRL) ? 16 : 32;
            return (1ULL << (shift + FILTER_TABLE[i].subtype));
        }
    }
    if (strcasecmp(name, "all") == 0) {
        return 0xFFFFFFFFFFFFFFFFULL;
    }
    return 0;
}
