/*
 * sniffer_main.c
 * ------------------------------------------------------------
 * Lõi sniffer 802.11 cho ESP32, viết cho ESP-IDF 5.1.
 *
 * QUAN TRỌNG VỀ PHẠM VI:
 *   - File này CHỈ dùng các API "nhận": esp_wifi_set_promiscuous(),
 *     esp_wifi_set_promiscuous_rx_cb(), esp_wifi_set_promiscuous_filter().
 *   - KHÔNG có bất kỳ lời gọi esp_wifi_80211_tx() nào trong toàn bộ
 *     project này -> không có khả năng phát/giả mạo bất kỳ frame
 *     802.11 nào (bao gồm deauth/disassoc). Đây là sniffer thuần
 *     thụ động, chỉ nghe những gì đã có sẵn trong không khí.
 * ------------------------------------------------------------
 */
#include <string.h>
#include <strings.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "sdkconfig.h"

#include "sniffer.h"
#include "frame_types.h"
#include "web_server.h"

static const char *TAG = "sniffer_core";

// ---- Trạng thái nội bộ ----
static volatile uint8_t   s_current_channel = CONFIG_SNIFFER_DEFAULT_CHANNEL;
static volatile uint32_t  s_hop_interval_ms  = 0; // 0 = tắt hopping
static volatile uint64_t  s_filter_mask      = 0xFFFFFFFFFFFFFFFFULL; // mặc định: cho qua tất cả
static sniffer_packet_cb_t s_output_cb       = NULL;
static SemaphoreHandle_t   s_stats_mutex     = NULL;
static sniffer_stats_t     s_stats           = {0};
static uint32_t            s_subtype_counts[SNIFFER_SUBTYPE_SLOTS] = {0};
static TaskHandle_t        s_hop_task_handle = NULL;
static volatile bool       s_is_running      = false;

// Buffer tạm để ghép [pcap_rec_hdr_t][payload] trước khi đẩy ra callback.
// Cấp phát tĩnh để tránh phân mảnh heap trong ngữ cảnh callback Wi-Fi
// (callback chạy trong context ưu tiên cao, không nên malloc ở đây).
#define MAX_FRAME_LEN 2346
static uint8_t s_out_buf[sizeof(pcap_rec_hdr_t) + MAX_FRAME_LEN];

// ------------------------------------------------------------
// Phân loại nhanh nhóm frame từ 2 byte Frame Control đầu tiên,
// chỉ dùng để cập nhật thống kê / áp dụng filter mask, KHÔNG
// chỉnh sửa hay dựng lại frame.
// ------------------------------------------------------------
static inline frame_group_t classify_group(uint16_t frame_control)
{
    return (frame_group_t)((frame_control >> 2) & 0x3);
}

static inline uint8_t classify_subtype(uint16_t frame_control)
{
    return (uint8_t)((frame_control >> 4) & 0xF);
}

// Vị trí bit trong filter mask: bit 0-15 dành cho mgmt subtype (0-15),
// bit 16-19 dành cho ctrl subtype rút gọn, bit 32-47 dành cho data subtype.
// sniffer_main không tự diễn giải ý nghĩa bit; đó là việc của web_server.c
// khi build mask từ tên lệnh người dùng gõ (/filter beacon ...).
static inline uint64_t bit_for(frame_group_t g, uint8_t subtype)
{
    switch (g) {
        case FRAME_GROUP_MGMT: return (uint64_t)1ULL << subtype;              // bit 0-15
        case FRAME_GROUP_CTRL: return (uint64_t)1ULL << (16 + subtype);       // bit 16-31
        case FRAME_GROUP_DATA: return (uint64_t)1ULL << (32 + subtype);       // bit 32-47
        default: return 0;
    }
}

// ------------------------------------------------------------
// Callback promiscuous — được Wi-Fi driver gọi cho MỖI gói nhận
// được trên kênh hiện tại. Đây là điểm duy nhất xử lý dữ liệu
// gói tin trong toàn bộ project.
// ------------------------------------------------------------
static void IRAM_ATTR wifi_sniffer_cb(void *buf, wifi_promiscuous_pkt_type_t type)
{
    const wifi_promiscuous_pkt_t *pkt = (const wifi_promiscuous_pkt_t *)buf;
    uint16_t len = pkt->rx_ctrl.sig_len;

    if (len < 2) {
        return; // gói lỗi/quá ngắn để đọc Frame Control
    }
    if (len > MAX_FRAME_LEN) {
        len = MAX_FRAME_LEN; // cắt bớt an toàn, tránh tràn buffer tĩnh
    }

    uint16_t frame_control = pkt->payload[0] | (pkt->payload[1] << 8);
    frame_group_t group = classify_group(frame_control);
    uint8_t subtype = classify_subtype(frame_control);

    // ---- cập nhật thống kê (luôn đếm, không phụ thuộc filter) ----
    if (s_stats_mutex && xSemaphoreTake(s_stats_mutex, 0) == pdTRUE) {
        s_stats.total++;
        if (group == FRAME_GROUP_MGMT) s_stats.mgmt++;
        else if (group == FRAME_GROUP_CTRL) s_stats.ctrl++;
        else if (group == FRAME_GROUP_DATA) s_stats.data++;

        int slot = (int)group * 16 + subtype;
        if (slot >= 0 && slot < SNIFFER_SUBTYPE_SLOTS) {
            s_subtype_counts[slot]++;
        }
        xSemaphoreGive(s_stats_mutex);
    }

    // ---- áp dụng filter mask: chỉ đẩy ra client những loại được bật ----
    uint64_t mask = s_filter_mask;
    if ((mask & bit_for(group, subtype)) == 0) {
        return; // gói bị lọc, không đẩy ra web nhưng đã tính vào thống kê ở trên
    }

    if (!s_output_cb) {
        return; // chưa có client nào đăng ký nhận
    }

    // ---- đóng gói pcap record header + payload rồi đẩy ra ngoài ----
    pcap_rec_hdr_t rec = {
        .ts_sec    = (uint32_t)(esp_timer_get_time() / 1000000ULL),
        .ts_usec   = (uint32_t)(esp_timer_get_time() % 1000000ULL),
        .incl_len  = len,
        .orig_len  = pkt->rx_ctrl.sig_len,
    };

    memcpy(s_out_buf, &rec, sizeof(rec));
    memcpy(s_out_buf + sizeof(rec), pkt->payload, len);
    s_output_cb(s_out_buf, sizeof(rec) + len);
}

// ------------------------------------------------------------
// Task đổi kênh định kỳ (channel hopping), chỉ chạy khi
// s_hop_interval_ms > 0. Việc đổi kênh không liên quan gì tới
// việc gửi frame — chỉ thay đổi tần số ESP32 đang LẮNG NGHE.
// ------------------------------------------------------------
static void channel_hop_task(void *arg)
{
    while (1) {
        uint32_t interval = s_hop_interval_ms;
        if (interval == 0) {
            vTaskDelay(pdMS_TO_TICKS(200));
            continue;
        }
        uint8_t next = s_current_channel + 1;
        if (next > 13) next = 1;
        sniffer_set_channel(next);
        vTaskDelay(pdMS_TO_TICKS(interval));
    }
}

// ------------------------------------------------------------
// API công khai
// ------------------------------------------------------------
esp_err_t sniffer_start(void)
{
    if (s_is_running) {
        return ESP_OK; // đã chạy rồi, không cần làm lại
    }

    // Bật lọc ở tầng driver để nhận đủ 3 nhóm Mgmt/Ctrl/Data.
    wifi_promiscuous_filter_t filter = {
        .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT |
                        WIFI_PROMIS_FILTER_MASK_CTRL |
                        WIFI_PROMIS_FILTER_MASK_DATA,
    };
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous_filter(&filter));
    ESP_ERROR_CHECK(esp_wifi_set_channel(s_current_channel, WIFI_SECOND_CHAN_NONE));
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous_rx_cb(&wifi_sniffer_cb));
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous(true));

    s_is_running = true;
    ESP_LOGI(TAG, "Sniffer started on channel %d", s_current_channel);
    return ESP_OK;
}

void sniffer_stop(void)
{
    esp_wifi_set_promiscuous(false);
    s_is_running = false;
    ESP_LOGI(TAG, "Sniffer stopped (promiscuous off)");
}

bool sniffer_is_running(void)
{
    return s_is_running;
}

// ------------------------------------------------------------
// Scan chủ động để xác định chính xác kênh của 1 SSID, dùng
// esp_wifi_scan_start() — API quét tiêu chuẩn, giống hệt việc
// điện thoại "dò danh sách Wi-Fi". Đây là quét BỊ ĐỘNG dựa trên
// beacon mà AP tự phát ra định kỳ, không gửi bất kỳ frame lạ nào
// ngoài Probe Request tiêu chuẩn (nếu active scan) mà mọi thiết
// bị Wi-Fi vẫn làm khi tìm mạng.
// ------------------------------------------------------------
esp_err_t sniffer_scan_and_lock(const char *ssid_query, sniffer_scan_result_t *out_result)
{
    if (!ssid_query || !out_result) {
        return ESP_ERR_INVALID_ARG;
    }
    memset(out_result, 0, sizeof(*out_result));

    // Sniffer đang ở promiscuous mode -> phải tắt tạm thời để chạy
    // scan (driver không cho scan trong lúc promiscuous bật), rồi
    // bật lại sau khi có kết quả.
    bool was_promiscuous;
    esp_wifi_get_promiscuous(&was_promiscuous);
    if (was_promiscuous) {
        esp_wifi_set_promiscuous(false);
    }

    wifi_scan_config_t scan_cfg = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,          // 0 = quét toàn bộ kênh 1-13
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
        .scan_time.active.min = 100,
        .scan_time.active.max = 300,
    };

    esp_err_t err = esp_wifi_scan_start(&scan_cfg, true /* block cho tới khi xong */);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_wifi_scan_start that bai: %s", esp_err_to_name(err));
        goto restore_promiscuous;
    }

    uint16_t ap_count = 0;
    esp_wifi_scan_get_ap_num(&ap_count);
    if (ap_count == 0) {
        ESP_LOGW(TAG, "Scan xong nhung khong thay AP nao");
        goto restore_promiscuous;
    }

    wifi_ap_record_t *ap_list = calloc(ap_count, sizeof(wifi_ap_record_t));
    if (!ap_list) {
        err = ESP_ERR_NO_MEM;
        goto restore_promiscuous;
    }

    err = esp_wifi_scan_get_ap_records(&ap_count, ap_list);
    if (err == ESP_OK) {
        for (int i = 0; i < ap_count; i++) {
            if (strcasecmp((const char *)ap_list[i].ssid, ssid_query) == 0) {
                out_result->found   = true;
                out_result->channel = ap_list[i].primary;
                out_result->rssi    = ap_list[i].rssi;
                memcpy(out_result->bssid, ap_list[i].bssid, 6);
                strncpy(out_result->ssid, (const char *)ap_list[i].ssid, sizeof(out_result->ssid) - 1);
                break;
            }
        }
    }
    free(ap_list);

    if (out_result->found) {
        ESP_LOGI(TAG, "Tim thay SSID '%s' tren kenh %d (RSSI %d) -> khoa kenh",
                 out_result->ssid, out_result->channel, out_result->rssi);
        sniffer_set_channel(out_result->channel);
    } else {
        ESP_LOGW(TAG, "Khong tim thay SSID '%s' trong %d AP quet duoc", ssid_query, ap_count);
    }

restore_promiscuous:
    if (was_promiscuous) {
        esp_wifi_set_promiscuous(true);
    }
    return err;
}

esp_err_t sniffer_set_channel(uint8_t channel)
{
    if (channel < 1 || channel > 13) {
        return ESP_ERR_INVALID_ARG;
    }
    esp_err_t err = esp_wifi_set_channel(channel, WIFI_SECOND_CHAN_NONE);
    if (err == ESP_OK) {
        s_current_channel = channel;
    }
    return err;
}

uint8_t sniffer_get_channel(void)
{
    return s_current_channel;
}

void sniffer_set_hop_interval(uint32_t interval_ms)
{
    s_hop_interval_ms = interval_ms;
    ESP_LOGI(TAG, "Channel hopping interval = %lu ms", (unsigned long)interval_ms);
}

void sniffer_set_filter_mask(uint64_t mask)
{
    s_filter_mask = mask;
}

uint64_t sniffer_get_filter_mask(void)
{
    return s_filter_mask;
}

void sniffer_register_output_cb(sniffer_packet_cb_t cb)
{
    s_output_cb = cb;
}

void sniffer_get_stats(sniffer_stats_t *out)
{
    if (!out) return;
    if (s_stats_mutex && xSemaphoreTake(s_stats_mutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        *out = s_stats;
        xSemaphoreGive(s_stats_mutex);
    }
}

void sniffer_reset_stats(void)
{
    if (s_stats_mutex && xSemaphoreTake(s_stats_mutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        memset(&s_stats, 0, sizeof(s_stats));
        memset(s_subtype_counts, 0, sizeof(s_subtype_counts));
        xSemaphoreGive(s_stats_mutex);
    }
}

void sniffer_get_subtype_counts(uint32_t out_counts[SNIFFER_SUBTYPE_SLOTS])
{
    if (!out_counts) return;
    if (s_stats_mutex && xSemaphoreTake(s_stats_mutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        memcpy(out_counts, s_subtype_counts, sizeof(s_subtype_counts));
        xSemaphoreGive(s_stats_mutex);
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "Khoi dong ESP32 passive sniffer (ESP-IDF %s)", IDF_VER);

    // Chỉ khởi tạo Wi-Fi stack + AP + web server ngay từ đầu, để điện
    // thoại luôn vào được trang web. Việc BẮT ĐẦU nhận gói (promiscuous)
    // giờ do người dùng bấm nút Start trên giao diện web quyết định,
    // không tự động chạy khi cắm điện nữa.
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t ap_cfg = {
        .ap = {
            .ssid = CONFIG_SNIFFER_AP_SSID,
            .ssid_len = strlen(CONFIG_SNIFFER_AP_SSID),
            .password = CONFIG_SNIFFER_AP_PASS,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA2_PSK,
        },
    };
    if (strlen(CONFIG_SNIFFER_AP_PASS) == 0) {
        ap_cfg.ap.authmode = WIFI_AUTH_OPEN;
    }

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    if (!s_stats_mutex) {
        s_stats_mutex = xSemaphoreCreateMutex();
    }
    if (!s_hop_task_handle) {
        xTaskCreate(channel_hop_task, "chan_hop", 2048, NULL, 5, &s_hop_task_handle);
    }

    web_server_start(); // sẵn sàng nhận lệnh /start /stop qua websocket
    ESP_LOGI(TAG, "San sang. Vao trang web va go /start de bat dau sniff.");
}
