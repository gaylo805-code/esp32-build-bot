/*
 * sniffer.h
 * ------------------------------------------------------------
 * Giao diện chung giữa module sniffer (sniffer_main.c) và
 * module web server / websocket (web_server.c).
 * ------------------------------------------------------------
 */
#pragma once

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// Khởi động Wi-Fi ở chế độ AP+STA, bật promiscuous mode và đăng ký
// callback nhận gói. KHÔNG bật bất kỳ chức năng gửi frame nào.
esp_err_t sniffer_start(void);

// Dừng promiscuous mode (không tắt AP, để vẫn tải được trang web nếu cần)
void sniffer_stop(void);

// Đổi kênh sniff hiện tại (1-13)
esp_err_t sniffer_set_channel(uint8_t channel);
uint8_t sniffer_get_channel(void);

// Bật/tắt channel hopping tự động, interval tính bằng ms (0 = tắt)
void sniffer_set_hop_interval(uint32_t interval_ms);

// ------------------------------------------------------------
// Scan chủ động (esp_wifi_scan_start) để tìm chính xác kênh mà
// một SSID cụ thể đang phát, rồi tự chuyển sniffer sang đúng
// kênh đó. Đây là quét bị động tiêu chuẩn của Wi-Fi (giống việc
// điện thoại "dò mạng"), không liên quan tới việc gửi frame giả.
// ------------------------------------------------------------
typedef struct {
    bool     found;
    char     ssid[33];
    uint8_t  channel;
    int8_t   rssi;
    uint8_t  bssid[6];
} sniffer_scan_result_t;

// Chạy scan đồng bộ (chặn vài giây), tìm SSID khớp chuỗi truyền vào
// (so khớp chính xác, không phân biệt hoa/thường). Nếu found=true,
// tự động gọi sniffer_set_channel() sang kênh tìm được.
// Trả ESP_OK nếu quá trình scan chạy được (found có thể vẫn false
// nếu không thấy SSID đó trong lần quét).
esp_err_t sniffer_scan_and_lock(const char *ssid_query, sniffer_scan_result_t *out_result);

// Bitmask các nhóm/subtype đang được phép đẩy ra web client.
// Việc lọc này chỉ ảnh hưởng đến HIỂN THỊ phía client, sniffer vẫn
// nhận tất cả gói để đếm thống kê đúng.
void sniffer_set_filter_mask(uint64_t mask);
uint64_t sniffer_get_filter_mask(void);

// Con trỏ hàm được web_server.c cung cấp để sniffer_main.c gọi mỗi
// khi có 1 gói mới cần đẩy ra toàn bộ websocket client đang mở.
typedef void (*sniffer_packet_cb_t)(const uint8_t *pcap_record, size_t len);
void sniffer_register_output_cb(sniffer_packet_cb_t cb);

// Thống kê nhanh theo nhóm (dùng cho lệnh /stats)
typedef struct {
    uint32_t total;
    uint32_t mgmt;
    uint32_t ctrl;
    uint32_t data;
} sniffer_stats_t;
void sniffer_get_stats(sniffer_stats_t *out);
void sniffer_reset_stats(void);

// Thống kê chi tiết theo TỪNG subtype cụ thể (Beacon, Deauth, RTS...)
// mảng 48 phần tử: index = group*16 + subtype (group: 0=mgmt,1=ctrl,2=data)
// Dùng để hiện bảng "loại gói nào đang thực sự bắt được, bao nhiêu cái".
#define SNIFFER_SUBTYPE_SLOTS 48
void sniffer_get_subtype_counts(uint32_t out_counts[SNIFFER_SUBTYPE_SLOTS]);

// Trạng thái chạy hiện tại (để giao diện web hiện đúng nút Start/Stop)
bool sniffer_is_running(void);

#ifdef __cplusplus
}
#endif
